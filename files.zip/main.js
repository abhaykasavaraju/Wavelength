import { redirectToSpotify, exchangeCode, isLoggedIn, logout } from './auth.js';
import { getMe, getRecommendations, getMoodGenres, createPlaylist } from './spotify.js';

const MOODS = [
  { id: 'happy',    emoji: '☀️', name: 'Happy',    vibe: 'upbeat & bright' },
  { id: 'energetic',emoji: '⚡', name: 'Energetic', vibe: 'high tempo & hype' },
  { id: 'chill',    emoji: '🌊', name: 'Chill',    vibe: 'calm & mellow' },
  { id: 'sad',      emoji: '🌧️', name: 'Sad',      vibe: 'slow & reflective' },
  { id: 'romantic', emoji: '🌹', name: 'Romantic', vibe: 'warm & tender' },
  { id: 'angry',    emoji: '🔥', name: 'Angry',    vibe: 'intense & raw' },
];

let state = {
  user: null,
  selectedMood: null,
  tracks: [],
  currentAudio: null,
  playingId: null,
};

function ms2min(ms) {
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function showToast(msg, isError = false) {
  const t = document.createElement('div');
  t.className = 'toast' + (isError ? ' error' : '');
  t.textContent = msg;
  document.body.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 300);
  }, 3000);
}

function renderLogin() {
  document.getElementById('app').innerHTML = `
    <div class="login-screen">
      <div class="logo">Mood<span>Tunes</span></div>
      <p class="tagline">your mood. your music. instantly.</p>
      <button class="btn-spotify" id="btn-login">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/></svg>
        Connect with Spotify
      </button>
    </div>
  `;
  document.getElementById('btn-login').addEventListener('click', redirectToSpotify);
}

function renderApp() {
  document.getElementById('app').innerHTML = `
    <div class="app-layout">
      <header class="app-header">
        <div class="app-logo">Mood<span>Tunes</span></div>
        <div class="user-info">
          ${state.user?.images?.[0]?.url ? `<img class="user-avatar" src="${state.user.images[0].url}" alt="${state.user.display_name}">` : ''}
          <span class="user-name">${state.user?.display_name || ''}</span>
          <button class="btn-logout" id="btn-logout">logout</button>
        </div>
      </header>

      <p class="section-label">How are you feeling?</p>
      <div class="mood-grid">
        ${MOODS.map(m => `
          <div class="mood-card ${state.selectedMood === m.id ? 'active' : ''}" data-mood="${m.id}">
            <span class="mood-emoji">${m.emoji}</span>
            <span class="mood-name">${m.name}</span>
            <span class="mood-vibe">${m.vibe}</span>
          </div>
        `).join('')}
      </div>

      <button class="btn-generate ${state.selectedMood ? 'ready' : ''}" id="btn-generate">
        ${state.selectedMood ? `Generate ${MOODS.find(m=>m.id===state.selectedMood).name} playlist` : 'Select a mood first'}
      </button>

      <div id="tracks-container"></div>
    </div>
  `;

  document.getElementById('btn-logout').addEventListener('click', logout);

  document.querySelectorAll('.mood-card').forEach(card => {
    card.addEventListener('click', () => {
      state.selectedMood = card.dataset.mood;
      state.tracks = [];
      stopAudio();
      renderApp();
    });
  });

  const genBtn = document.getElementById('btn-generate');
  if (state.selectedMood) {
    genBtn.addEventListener('click', generatePlaylist);
  }

  if (state.tracks.length > 0) {
    renderTracks();
  }
}

function renderTracks() {
  const container = document.getElementById('tracks-container');
  const mood = MOODS.find(m => m.id === state.selectedMood);

  container.innerHTML = `
    <div class="tracks-section">
      <div class="tracks-header">
        <p class="section-label">${mood.emoji} ${mood.name} playlist</p>
        <span class="track-count">${state.tracks.length} tracks</span>
      </div>
      <div class="track-list">
        ${state.tracks.map((t, i) => `
          <div class="track" style="animation-delay: ${i * 30}ms">
            <span class="track-num">${i + 1}</span>
            ${t.album?.images?.[0]?.url
              ? `<img class="track-art" src="${t.album.images[0].url}" alt="${t.album.name}">`
              : `<div class="track-art-placeholder">♪</div>`}
            <div class="track-info">
              <div class="track-name">${t.name}</div>
              <div class="track-artist">${t.artists.map(a => a.name).join(', ')}</div>
            </div>
            <span class="track-duration">${ms2min(t.duration_ms)}</span>
            ${t.preview_url ? `
              <button class="track-preview ${state.playingId === t.id ? 'playing' : ''}" data-id="${t.id}" data-url="${t.preview_url}" title="Preview">
                ${state.playingId === t.id
                  ? `<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>`
                  : `<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="5,3 19,12 5,21"/></svg>`}
              </button>
            ` : ''}
          </div>
        `).join('')}
      </div>
      <button class="btn-save" id="btn-save">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/></svg>
        Save to Spotify
      </button>
      <button class="btn-regenerate" id="btn-regen">Regenerate playlist ↺</button>
    </div>
  `;

  document.getElementById('btn-save').addEventListener('click', savePlaylist);
  document.getElementById('btn-regen').addEventListener('click', generatePlaylist);

  document.querySelectorAll('.track-preview').forEach(btn => {
    btn.addEventListener('click', () => togglePreview(btn.dataset.id, btn.dataset.url));
  });
}

async function generatePlaylist() {
  const genBtn = document.getElementById('btn-generate');
  genBtn.className = 'btn-generate loading';
  genBtn.textContent = 'Finding tracks…';

  stopAudio();
  state.tracks = [];

  try {
    const genres = getMoodGenres(state.selectedMood);
    const data = await getRecommendations(state.selectedMood, genres);
    state.tracks = data.tracks;
    renderApp();
    renderTracks();
    document.getElementById('tracks-container').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (e) {
    showToast(e.message || 'Could not load tracks', true);
    renderApp();
  }
}

async function savePlaylist() {
  const btn = document.getElementById('btn-save');
  btn.disabled = true;
  btn.textContent = 'Saving…';
  try {
    const playlist = await createPlaylist(state.user.id, state.selectedMood, state.tracks);
    showToast(`Playlist saved! "${playlist.name}"`);
    btn.textContent = '✓ Saved to Spotify';
  } catch (e) {
    showToast(e.message || 'Could not save playlist', true);
    btn.disabled = false;
    btn.textContent = 'Save to Spotify';
  }
}

function togglePreview(id, url) {
  if (state.playingId === id) {
    stopAudio();
    state.playingId = null;
  } else {
    stopAudio();
    state.currentAudio = new Audio(url);
    state.currentAudio.volume = 0.6;
    state.currentAudio.play();
    state.currentAudio.addEventListener('ended', () => {
      state.playingId = null;
      renderTracks();
    });
    state.playingId = id;
  }
  renderTracks();
}

function stopAudio() {
  if (state.currentAudio) {
    state.currentAudio.pause();
    state.currentAudio = null;
  }
  state.playingId = null;
}

async function init() {
  const url = new URL(window.location.href);

  // Handle OAuth callback
  if (url.searchParams.has('code')) {
    const code = url.searchParams.get('code');
    window.history.replaceState({}, '', '/');
    try {
      await exchangeCode(code);
    } catch (e) {
      showToast('Login failed. Please try again.', true);
      renderLogin();
      return;
    }
  }

  if (!isLoggedIn()) {
    renderLogin();
    return;
  }

  try {
    state.user = await getMe();
    renderApp();
  } catch (e) {
    renderLogin();
  }
}

init();
